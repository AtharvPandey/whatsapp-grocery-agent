# 🛒 KiranaAI — WhatsApp-based Grocery Management System

A production-ready MVP for Indian kirana stores to manage inventory and receive orders via WhatsApp with AI-powered natural language understanding.

---

## What This System Does

| Feature | How |
|---|---|
| Customer orders via WhatsApp | Twilio webhook → AI parser → order created |
| Hindi-English mixed input | OpenAI GPT-4o-mini understands "2 kg atta aur ek tel" |
| Inventory management | Web dashboard with real-time stock |
| Low stock alerts | Dashboard shows items below threshold |
| Order lifecycle | pending → confirmed → preparing → ready → delivered |
| Stock safety | Transactional deduction prevents negative stock |

---

## Quick Start

### 1. Clone and enter the project
```bash
git clone <repo>
cd kirana-ai
```

### 2. Create a Python virtual environment
```bash
python -m venv venv
source venv/bin/activate        # Linux/Mac
# venv\Scripts\activate         # Windows
```

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

### 4. Set up environment variables
```bash
cp .env.example .env
# Edit .env with your actual keys (see Configuration section below)
```

### 5. Create the logs directory
```bash
mkdir logs
```

### 6. Run the server
```bash
uvicorn app.main:app --reload --port 8000
```

### 7. Open the dashboard
```
http://localhost:8000
```
API docs: `http://localhost:8000/api/docs`

---

## Configuration (.env)

| Variable | Required | Description |
|---|---|---|
| `DATABASE_URL` | No | Defaults to SQLite. Change to PostgreSQL URL for production |
| `OPENAI_API_KEY` | **Yes** | For AI order parsing. Get from platform.openai.com |
| `OPENAI_MODEL` | No | Defaults to `gpt-4o-mini` (cheapest, fast enough) |
| `TWILIO_ACCOUNT_SID` | Yes (for WhatsApp) | From Twilio console |
| `TWILIO_AUTH_TOKEN` | Yes (for WhatsApp) | From Twilio console |
| `TWILIO_WHATSAPP_NUMBER` | No | Sandbox: `whatsapp:+14155238886` |
| `STORE_NAME` | No | Shown in WhatsApp messages |
| `STORE_PHONE` | No | Fallback number in error messages |
| `DEBUG` | No | `true` for dev (seeds demo data, verbose SQL) |

---

## WhatsApp Setup (Twilio Sandbox)

1. Go to [Twilio Console](https://console.twilio.com) → Messaging → Try it out → Send a WhatsApp message
2. Join the sandbox by sending the join code from your phone
3. Set the webhook URL in Twilio sandbox settings:
   ```
   https://YOUR_DOMAIN/webhook/whatsapp
   ```
   (Use [ngrok](https://ngrok.com) for local development: `ngrok http 8000`)
4. Select **HTTP POST** as the method

### Local development with ngrok
```bash
# In a separate terminal:
ngrok http 8000

# Copy the https URL (e.g. https://abc123.ngrok.io)
# Set as Twilio webhook: https://abc123.ngrok.io/webhook/whatsapp
```

---

## Example WhatsApp Conversation

```
Customer: Namaste! 2 kg atta aur 1 litre tel chahiye

System:  ✅ Order Confirm Ho Gaya! (#42)
         • Atta (Wheat Flour): 2 kg — ₹70
         • Mustard Oil: 1 litre — ₹160
         
         💰 Total: ₹230
         Hum aapka order jaldi bhej denge! 🚀

Customer: mera order
System:  Order #42 Status: ✅ Confirmed | ₹230 | 03 Jan, 02:30 PM
```

---

## Project Structure

```
kirana-ai/
├── app/
│   ├── main.py              # FastAPI app, startup, routing
│   ├── config.py            # Pydantic settings from .env
│   ├── database.py          # SQLAlchemy engine + session
│   ├── models/              # ORM models (Product, Order, Customer, Message)
│   ├── schemas/             # Pydantic request/response schemas
│   ├── routes/
│   │   ├── products.py      # REST API: /api/products
│   │   ├── orders.py        # REST API: /api/orders
│   │   ├── webhook.py       # POST /webhook/whatsapp (Twilio)
│   │   └── dashboard.py     # HTML pages for owner UI
│   ├── services/
│   │   ├── inventory_service.py  # Stock logic (CRUD + transactional reserve)
│   │   └── order_service.py      # Order lifecycle + daily summary
│   ├── ai/
│   │   └── order_parser.py  # OpenAI integration for NL order parsing
│   ├── whatsapp/
│   │   └── handler.py       # Conversation engine + Twilio sender
│   └── templates/           # Jinja2 HTML templates
│       ├── base.html
│       └── dashboard/
│           ├── home.html
│           ├── inventory.html
│           └── orders.html
├── static/                  # CSS, JS assets
├── logs/                    # Rotating log files
├── requirements.txt
├── .env.example
└── README.md
```

---

## API Reference

### Products
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/products/` | List all products |
| GET | `/api/products/search?q=atta` | Search by name |
| GET | `/api/products/low-stock` | Low stock items |
| POST | `/api/products/` | Add product |
| PATCH | `/api/products/{id}` | Update product |
| DELETE | `/api/products/{id}` | Soft delete |
| POST | `/api/products/{id}/adjust-stock` | Add/remove stock |

### Orders
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/orders/` | List orders (filter: `?status=pending`) |
| GET | `/api/orders/summary` | Today's summary |
| POST | `/api/orders/` | Create order manually |
| PATCH | `/api/orders/{id}/status` | Update status |

### WhatsApp
| Method | Endpoint | Description |
|---|---|---|
| POST | `/webhook/whatsapp` | Twilio inbound webhook |

---

## Migrating to PostgreSQL

When you're ready to scale:

1. Change `.env`:
   ```
   DATABASE_URL=postgresql+psycopg2://user:password@host:5432/kirana_db
   ```
2. Install driver:
   ```bash
   pip install psycopg2-binary
   ```
3. Restart — SQLAlchemy handles the rest automatically.

---

## Migrating from Twilio to Meta WhatsApp Cloud API

Only `app/whatsapp/handler.py → send_whatsapp()` needs updating.
The conversation logic, AI parser, and order creation are all unchanged.

---

## Cost Estimates (per month, 500 orders)

| Service | Cost |
|---|---|
| OpenAI GPT-4o-mini | ~$0.50 (500 × $0.001) |
| Twilio WhatsApp | ~$0 sandbox / ~$5 production |
| Render hosting (free tier) | $0 |
| **Total** | **~$5–6/month** |

---

## Production Checklist

- [ ] Change `DEBUG=false` in `.env`
- [ ] Set a strong `APP_SECRET_KEY`
- [ ] Enable Twilio signature verification in `routes/webhook.py`
- [ ] Switch `DATABASE_URL` to PostgreSQL
- [ ] Set up Render / Railway / AWS deployment
- [ ] Configure `ngrok` → real domain for webhook
- [ ] Add rate limiting (slowapi already in requirements)
- [ ] Set up log monitoring (loguru writes to `logs/kirana.log`)

---

## Roadmap (Post-MVP)

- [ ] Payment integration (Razorpay / UPI QR)
- [ ] Customer loyalty points
- [ ] Barcode scanning for stock entry
- [ ] Multi-store / SaaS mode
- [ ] SMS fallback for non-WhatsApp customers
- [ ] Analytics dashboard
- [ ] Voice ordering (Whisper API)
- [ ] Auto low-stock WhatsApp alerts to owner
