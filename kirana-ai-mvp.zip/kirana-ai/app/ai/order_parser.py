"""
ai/order_parser.py
-------------------
The AI brain of the system.

Why OpenAI for parsing?
  Grocery orders in Hindi-English mix are nearly impossible to parse
  with regex. GPT-4o-mini is cheap (~$0.001 per order) and handles:
  - "2 kg atta aur ek tel" → {"atta": 2kg, "oil": 1}
  - Spelling variants: "aata", "atta", "आटा" all map to the same product
  - Implied units: "ek packet" → quantity 1
  - Mixed script naturally

After the AI extracts (product_name, quantity) pairs, we do a DB
fuzzy-match so the AI can't invent products that don't exist in inventory.
"""

import json
import re
from typing import List, Optional
from openai import OpenAI
from loguru import logger
from sqlalchemy.orm import Session

from app.config import settings
from app.models import Product
from app.schemas import ParsedItem, ParsedOrder
from app.services import inventory_service


client = OpenAI(api_key=settings.OPENAI_API_KEY)

# ── System prompt ──────────────────────────────────────────────────────────────
# Strict JSON-only output so we can parse it reliably.
SYSTEM_PROMPT = """You are an AI assistant for an Indian kirana (grocery) store.
Your ONLY job is to extract grocery items and quantities from customer WhatsApp messages.

Rules:
1. Respond ONLY with valid JSON — no explanation, no markdown, no extra text.
2. Normalise product names to simple English (e.g. "aata"→"atta", "tel"→"oil", "chawal"→"rice").
3. Parse quantities: "2 kg", "ek", "1", "do", "tin" etc. Convert Hindi numbers to digits.
4. If no quantity is mentioned, assume 1.
5. Ignore greetings, chitchat — extract only grocery items.
6. If the message has NO grocery items, return {"items": []}.

Output format:
{
  "items": [
    {"product_name": "string", "quantity": number, "unit": "string or null"}
  ]
}

Hindi number mapping: ek=1, do=2, teen=3, char=4, paanch=5, chhe=6, saat=7, aath=8, nau=9, das=10
"""


def parse_order_message(message: str) -> ParsedOrder:
    """
    Call OpenAI to extract structured item list from a raw WhatsApp message.
    Returns ParsedOrder with a list of ParsedItem objects.
    """
    logger.info(f"Parsing message: {message[:100]}")

    try:
        response = client.chat.completions.create(
            model=settings.OPENAI_MODEL,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": message},
            ],
            temperature=0,          # deterministic — we want structured extraction
            max_tokens=500,
            response_format={"type": "json_object"},
        )

        raw = response.choices[0].message.content
        logger.debug(f"AI response: {raw}")
        data = json.loads(raw)

        items = []
        for item_data in data.get("items", []):
            try:
                qty = float(item_data.get("quantity", 1))
            except (TypeError, ValueError):
                qty = 1.0

            items.append(ParsedItem(
                product_name=item_data.get("product_name", "").strip(),
                quantity=qty,
                unit=item_data.get("unit"),
            ))

        return ParsedOrder(items=items, raw_message=message)

    except Exception as e:
        logger.error(f"AI parsing failed: {e}")
        # Graceful degradation — return empty so the caller can ask customer to clarify
        return ParsedOrder(items=[], raw_message=message)


def match_parsed_items_to_inventory(
    db: Session, parsed: ParsedOrder
) -> tuple[list, list, list]:
    """
    Map AI-extracted item names to actual DB products.

    Returns three parallel lists:
      matched_products  – Product ORM objects that were found
      quantities        – corresponding quantities
      unmatched_names   – item names that had no DB match (out-of-stock or unknown)
    """
    matched_products = []
    quantities = []
    unmatched = []

    for item in parsed.items:
        name = item.product_name.lower().strip()
        results = inventory_service.search_products(db, name)

        if results:
            # Take the closest match (first result from LIKE query)
            product = results[0]
            matched_products.append(product)
            quantities.append(item.quantity)
        else:
            unmatched.append(item.product_name)
            logger.warning(f"No product found for: '{item.product_name}'")

    return matched_products, quantities, unmatched


def check_availability(
    products: list, quantities: list
) -> tuple[list, list, list]:
    """
    Split matched products into available vs out-of-stock.

    Returns:
      available_products, available_qtys  – can be fulfilled
      unavailable                         – list of (product, requested_qty) tuples
    """
    available_p, available_q, unavailable = [], [], []

    for product, qty in zip(products, quantities):
        if product.stock_quantity >= qty:
            available_p.append(product)
            available_q.append(qty)
        else:
            unavailable.append((product, qty))

    return available_p, available_q, unavailable
