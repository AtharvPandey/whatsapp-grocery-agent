"""
config.py
---------
Centralised settings loaded from environment variables / .env file.
Using pydantic-settings means values are type-checked at startup,
so misconfiguration fails loudly rather than silently at runtime.
"""

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    # Database
    DATABASE_URL: str = "sqlite:///./kirana.db"

    # OpenAI
    OPENAI_API_KEY: str = "sk-placeholder"
    OPENAI_MODEL: str = "gpt-4o-mini"

    # Twilio
    TWILIO_ACCOUNT_SID: str = ""
    TWILIO_AUTH_TOKEN: str = ""
    TWILIO_WHATSAPP_NUMBER: str = "whatsapp:+14155238886"

    # App
    APP_NAME: str = "KiranaAI"
    APP_SECRET_KEY: str = "change-me"
    DEBUG: bool = True
    LOG_LEVEL: str = "INFO"

    # Store
    STORE_NAME: str = "My Kirana Store"
    STORE_PHONE: str = ""
    LOW_STOCK_ALERT_THRESHOLD: int = 10

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")


# Single shared instance — import this everywhere
settings = Settings()
