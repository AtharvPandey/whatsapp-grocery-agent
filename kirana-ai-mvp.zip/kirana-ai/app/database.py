"""
database.py
-----------
Single source of truth for DB connection.

Why SQLAlchemy + SQLite for MVP?
  - Zero server setup, file-based, easy to back up
  - SQLAlchemy abstracts the SQL dialect, so migrating to PostgreSQL
    later is a one-line DATABASE_URL change + swap of the driver.

The `get_db` dependency is injected into every FastAPI route that
needs a DB session, ensuring sessions are always closed after use.
"""

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, DeclarativeBase
from app.config import settings

# ── Engine ────────────────────────────────────────────────────────────────────
# `check_same_thread=False` is required for SQLite + FastAPI's async nature.
# PostgreSQL doesn't need this flag; it's ignored when the URL changes.
connect_args = {"check_same_thread": False} if "sqlite" in settings.DATABASE_URL else {}

engine = create_engine(
    settings.DATABASE_URL,
    connect_args=connect_args,
    echo=settings.DEBUG,        # prints SQL in dev; set DEBUG=false in prod
)

# ── Session factory ───────────────────────────────────────────────────────────
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


# ── Base class for all ORM models ─────────────────────────────────────────────
class Base(DeclarativeBase):
    pass


# ── FastAPI dependency ────────────────────────────────────────────────────────
def get_db():
    """Yield a DB session; always close it when the request finishes."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
