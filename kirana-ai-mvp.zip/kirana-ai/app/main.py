"""
main.py
--------
FastAPI application bootstrap.

Startup order:
  1. Load config from .env
  2. Create DB tables (SQLAlchemy)
  3. Register routers
  4. Seed demo data if DB is empty (dev convenience)
  5. Start Uvicorn
"""

from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from fastapi.templating import Jinja2Templates
from loguru import logger
import sys

from app.config import settings
from app.database import engine, Base, SessionLocal
from app.routes import products, orders, webhook, dashboard


# ── Logging ────────────────────────────────────────────────────────────────────
logger.remove()
logger.add(sys.stderr, level=settings.LOG_LEVEL, colorize=True,
           format="<green>{time:HH:mm:ss}</green> | <level>{level}</level> | {message}")
logger.add("logs/kirana.log", rotation="10 MB", retention="7 days", level="DEBUG")


# ── DB init + optional seed ────────────────────────────────────────────────────

def init_db():
    """Create all tables if they don't exist."""
    Base.metadata.create_all(bind=engine)
    logger.info("Database tables created/verified")


def seed_demo_data():
    """Seed a few sample products so the dashboard isn't empty on first run."""
    from app.models import Product, ProductCategory
    from app.services.inventory_service import get_all_products

    db = SessionLocal()
    try:
        if get_all_products(db, limit=1):
            return  # Already has data

        demo_products = [
            Product(name="Atta (Wheat Flour)", name_hindi="आटा", category=ProductCategory.GRAINS,
                    stock_quantity=50, unit="kg", price=35.0, low_stock_threshold=10),
            Product(name="Basmati Rice", name_hindi="चावल", category=ProductCategory.GRAINS,
                    stock_quantity=30, unit="kg", price=80.0, low_stock_threshold=5),
            Product(name="Mustard Oil", name_hindi="सरसों तेल", category=ProductCategory.OILS,
                    stock_quantity=20, unit="litre", price=160.0, low_stock_threshold=5),
            Product(name="Sugar", name_hindi="चीनी", category=ProductCategory.GRAINS,
                    stock_quantity=25, unit="kg", price=42.0, low_stock_threshold=5),
            Product(name="Salt", name_hindi="नमक", category=ProductCategory.SPICES,
                    stock_quantity=40, unit="kg", price=18.0, low_stock_threshold=10),
            Product(name="Red Chilli Powder", name_hindi="लाल मिर्च", category=ProductCategory.SPICES,
                    stock_quantity=8, unit="kg", price=200.0, low_stock_threshold=10),
            Product(name="Toor Dal", name_hindi="तूर दाल", category=ProductCategory.GRAINS,
                    stock_quantity=15, unit="kg", price=120.0, low_stock_threshold=5),
            Product(name="Sunflower Oil", name_hindi="सूरजमुखी तेल", category=ProductCategory.OILS,
                    stock_quantity=12, unit="litre", price=140.0, low_stock_threshold=5),
            Product(name="Tea (Chai Patti)", name_hindi="चाय पत्ती", category=ProductCategory.BEVERAGES,
                    stock_quantity=3, unit="kg", price=280.0, low_stock_threshold=5),
            Product(name="Biscuits (Parle-G)", name_hindi="बिस्कुट", category=ProductCategory.SNACKS,
                    stock_quantity=100, unit="piece", price=5.0, low_stock_threshold=20),
        ]

        for p in demo_products:
            db.add(p)
        db.commit()
        logger.info(f"Seeded {len(demo_products)} demo products")
    finally:
        db.close()


# ── Lifespan ───────────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info(f"🛒 Starting {settings.APP_NAME}...")
    init_db()
    if settings.DEBUG:
        seed_demo_data()
    yield
    logger.info("Shutting down...")


# ── App ────────────────────────────────────────────────────────────────────────

app = FastAPI(
    title=f"{settings.APP_NAME} — Kirana Management System",
    description="WhatsApp-based AI grocery management for Indian kirana stores",
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/api/docs",
    redoc_url="/api/redoc",
)

# CORS — tighten in production to your actual domain
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"] if settings.DEBUG else ["https://yourdomain.com"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Static files
app.mount("/static", StaticFiles(directory="static"), name="static")

# ── Routers ────────────────────────────────────────────────────────────────────
app.include_router(dashboard.router)          # HTML pages (owner UI)
app.include_router(products.router)           # /api/products
app.include_router(orders.router)             # /api/orders
app.include_router(webhook.router)            # /webhook/whatsapp

logger.info("All routers registered")
