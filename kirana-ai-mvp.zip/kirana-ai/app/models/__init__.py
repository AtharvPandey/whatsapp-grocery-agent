"""
models/__init__.py
------------------
All ORM models live here. Keeping them in one file at MVP stage is fine;
they can be split per-domain as the codebase grows.

Design notes:
- ForeignKey relationships are explicit so SQLAlchemy can cascade correctly.
- `created_at` defaults to server time (not Python time) via server_default,
  which works correctly even when rows are inserted by raw SQL tools.
- Indexes are added on high-frequency query columns (phone, status).
"""

from datetime import datetime
from sqlalchemy import (
    Column, Integer, String, Float, DateTime, ForeignKey,
    Text, Enum as SAEnum, Index, func,
)
from sqlalchemy.orm import relationship
from app.database import Base
import enum


# ── Enums ─────────────────────────────────────────────────────────────────────

class OrderStatus(str, enum.Enum):
    PENDING   = "pending"
    CONFIRMED = "confirmed"
    PREPARING = "preparing"
    READY     = "ready"
    DELIVERED = "delivered"
    CANCELLED = "cancelled"


class ProductCategory(str, enum.Enum):
    GRAINS      = "Grains & Pulses"
    OILS        = "Oils & Ghee"
    SPICES      = "Spices & Masala"
    DAIRY       = "Dairy"
    SNACKS      = "Snacks & Biscuits"
    BEVERAGES   = "Beverages"
    PERSONAL    = "Personal Care"
    HOUSEHOLD   = "Household"
    VEGETABLES  = "Vegetables & Fruits"
    OTHER       = "Other"


# ── Products ──────────────────────────────────────────────────────────────────

class Product(Base):
    __tablename__ = "products"

    id                  = Column(Integer, primary_key=True, index=True)
    name                = Column(String(200), nullable=False, index=True)
    name_hindi          = Column(String(200), nullable=True)   # e.g. "आटा" for atta
    category            = Column(SAEnum(ProductCategory), default=ProductCategory.OTHER)
    stock_quantity      = Column(Float, nullable=False, default=0.0)
    unit                = Column(String(20), nullable=False, default="piece")  # kg, litre, piece, packet
    price               = Column(Float, nullable=False)        # price per unit in ₹
    low_stock_threshold = Column(Float, default=10.0)
    is_active           = Column(Integer, default=1)           # soft delete
    created_at          = Column(DateTime, server_default=func.now())
    updated_at          = Column(DateTime, server_default=func.now(), onupdate=func.now())

    # Back-reference to order items
    order_items = relationship("OrderItem", back_populates="product")

    def is_low_stock(self) -> bool:
        return self.stock_quantity <= self.low_stock_threshold

    def __repr__(self):
        return f"<Product {self.name} qty={self.stock_quantity}{self.unit}>"


# ── Customers ─────────────────────────────────────────────────────────────────

class Customer(Base):
    __tablename__ = "customers"

    id         = Column(Integer, primary_key=True, index=True)
    name       = Column(String(200), nullable=True)    # filled in after first order
    phone      = Column(String(20), unique=True, nullable=False, index=True)
    address    = Column(Text, nullable=True)
    created_at = Column(DateTime, server_default=func.now())

    orders   = relationship("Order", back_populates="customer")
    messages = relationship("Message", back_populates="customer",
                            foreign_keys="Message.customer_phone",
                            primaryjoin="Customer.phone == Message.customer_phone")

    def __repr__(self):
        return f"<Customer {self.phone}>"


# ── Orders ────────────────────────────────────────────────────────────────────

class Order(Base):
    __tablename__ = "orders"

    id           = Column(Integer, primary_key=True, index=True)
    customer_id  = Column(Integer, ForeignKey("customers.id"), nullable=False)
    total_amount = Column(Float, default=0.0)
    status       = Column(SAEnum(OrderStatus), default=OrderStatus.PENDING, index=True)
    notes        = Column(Text, nullable=True)           # delivery instructions etc.
    created_at   = Column(DateTime, server_default=func.now())
    updated_at   = Column(DateTime, server_default=func.now(), onupdate=func.now())

    customer    = relationship("Customer", back_populates="orders")
    items       = relationship("OrderItem", back_populates="order",
                               cascade="all, delete-orphan")

    def __repr__(self):
        return f"<Order #{self.id} {self.status}>"


# ── Order Items ───────────────────────────────────────────────────────────────

class OrderItem(Base):
    __tablename__ = "order_items"

    id         = Column(Integer, primary_key=True, index=True)
    order_id   = Column(Integer, ForeignKey("orders.id"), nullable=False)
    product_id = Column(Integer, ForeignKey("products.id"), nullable=False)
    quantity   = Column(Float, nullable=False)
    price      = Column(Float, nullable=False)   # price AT time of order (snapshot)

    order   = relationship("Order", back_populates="items")
    product = relationship("Product", back_populates="order_items")

    @property
    def subtotal(self) -> float:
        return round(self.quantity * self.price, 2)

    def __repr__(self):
        return f"<OrderItem {self.product_id} x{self.quantity}>"


# ── Messages (WhatsApp conversation log) ──────────────────────────────────────

class Message(Base):
    __tablename__ = "messages"

    id             = Column(Integer, primary_key=True, index=True)
    customer_phone = Column(String(20), ForeignKey("customers.phone"), nullable=False, index=True)
    direction      = Column(String(10), default="inbound")  # inbound | outbound
    message        = Column(Text, nullable=False)
    response       = Column(Text, nullable=True)
    timestamp      = Column(DateTime, server_default=func.now())

    customer = relationship("Customer", back_populates="messages",
                            foreign_keys=[customer_phone],
                            primaryjoin="Customer.phone == Message.customer_phone")

    def __repr__(self):
        return f"<Message from {self.customer_phone}>"
