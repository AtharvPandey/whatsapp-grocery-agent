"""
routes/dashboard.py
--------------------
Server-side rendered HTML pages for the store owner.
Uses Jinja2 templates + Bootstrap for a simple, low-tech-friendly UI.
"""

from fastapi import APIRouter, Depends, Request, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app.database import get_db
from app.services import inventory_service, order_service
from app.models import OrderStatus, ProductCategory
from app.schemas import ProductCreate, ProductUpdate, StockAdjust, OrderStatusUpdate

router = APIRouter(tags=["Dashboard"])
templates = Jinja2Templates(directory="app/templates")


@router.get("/", response_class=HTMLResponse)
def dashboard_home(request: Request, db: Session = Depends(get_db)):
    summary = order_service.get_daily_summary(db)
    pending_orders = order_service.get_orders(db, status=OrderStatus.PENDING, limit=10)
    low_stock = inventory_service.get_low_stock_products(db)
    return templates.TemplateResponse("dashboard/home.html", {
        "request": request,
        "summary": summary,
        "pending_orders": pending_orders,
        "low_stock": low_stock,
    })


@router.get("/inventory", response_class=HTMLResponse)
def inventory_page(request: Request, db: Session = Depends(get_db)):
    products = inventory_service.get_all_products(db, limit=500)
    categories = [c.value for c in ProductCategory]
    return templates.TemplateResponse("dashboard/inventory.html", {
        "request": request,
        "products": products,
        "categories": categories,
    })


@router.post("/inventory/add")
def add_product(
    request: Request,
    name: str = Form(...),
    name_hindi: str = Form(""),
    category: str = Form("Other"),
    stock_quantity: float = Form(...),
    unit: str = Form("piece"),
    price: float = Form(...),
    low_stock_threshold: float = Form(10.0),
    db: Session = Depends(get_db),
):
    data = ProductCreate(
        name=name,
        name_hindi=name_hindi or None,
        category=category,
        stock_quantity=stock_quantity,
        unit=unit,
        price=price,
        low_stock_threshold=low_stock_threshold,
    )
    inventory_service.create_product(db, data)
    return RedirectResponse("/inventory", status_code=303)


@router.post("/inventory/{product_id}/adjust")
def adjust_stock_form(
    product_id: int,
    quantity: float = Form(...),
    reason: str = Form(""),
    db: Session = Depends(get_db),
):
    try:
        inventory_service.adjust_stock(db, product_id, StockAdjust(quantity=quantity, reason=reason))
    except Exception as e:
        pass  # handle gracefully in real UI
    return RedirectResponse("/inventory", status_code=303)


@router.post("/inventory/{product_id}/delete")
def delete_product_form(product_id: int, db: Session = Depends(get_db)):
    inventory_service.delete_product(db, product_id)
    return RedirectResponse("/inventory", status_code=303)


@router.get("/orders", response_class=HTMLResponse)
def orders_page(request: Request, status: str = "", db: Session = Depends(get_db)):
    status_filter = OrderStatus(status) if status else None
    orders = order_service.get_orders(db, status=status_filter, limit=100)
    return templates.TemplateResponse("dashboard/orders.html", {
        "request": request,
        "orders": orders,
        "current_status": status,
        "all_statuses": [s.value for s in OrderStatus],
    })


@router.post("/orders/{order_id}/status")
def update_order_status_form(
    order_id: int,
    status: str = Form(...),
    db: Session = Depends(get_db),
):
    try:
        order_service.update_order_status(db, order_id, OrderStatus(status))
    except Exception:
        pass
    return RedirectResponse("/orders", status_code=303)
