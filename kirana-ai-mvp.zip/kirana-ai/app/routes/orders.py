"""
routes/orders.py
-----------------
Order management endpoints for the owner dashboard.
"""

from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import OrderStatus, OrderItem
from app.schemas import OrderCreate, OrderOut, OrderItemOut, OrderStatusUpdate, DailySummary
from app.services import order_service
from app.services.inventory_service import InsufficientStockError

router = APIRouter(prefix="/api/orders", tags=["Orders"])


def _item_to_out(item: OrderItem) -> OrderItemOut:
    return OrderItemOut(
        id=item.id,
        product_id=item.product_id,
        product_name=item.product.name,
        quantity=item.quantity,
        price=item.price,
        subtotal=item.subtotal,
        unit=item.product.unit,
    )


def _order_to_out(order) -> OrderOut:
    return OrderOut(
        id=order.id,
        customer_id=order.customer_id,
        customer_phone=order.customer.phone,
        total_amount=order.total_amount,
        status=order.status,
        notes=order.notes,
        created_at=order.created_at,
        items=[_item_to_out(i) for i in order.items],
    )


@router.get("/", response_model=List[OrderOut])
def list_orders(
    skip: int = 0,
    limit: int = 50,
    status: Optional[OrderStatus] = None,
    db: Session = Depends(get_db),
):
    """List orders. Filter by status e.g. ?status=pending"""
    orders = order_service.get_orders(db, skip=skip, limit=limit, status=status)
    return [_order_to_out(o) for o in orders]


@router.get("/summary", response_model=DailySummary)
def daily_summary(db: Session = Depends(get_db)):
    """Today's order summary — shown on dashboard home."""
    return order_service.get_daily_summary(db)


@router.get("/{order_id}", response_model=OrderOut)
def get_order(order_id: int, db: Session = Depends(get_db)):
    order = order_service.get_order(db, order_id)
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    return _order_to_out(order)


@router.post("/", response_model=OrderOut, status_code=201)
def create_order(data: OrderCreate, db: Session = Depends(get_db)):
    """Create an order manually (e.g. from dashboard or phone call)."""
    try:
        order = order_service.create_order(db, data)
        return _order_to_out(order)
    except InsufficientStockError as e:
        raise HTTPException(status_code=409, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.patch("/{order_id}/status", response_model=OrderOut)
def update_status(order_id: int, data: OrderStatusUpdate, db: Session = Depends(get_db)):
    """
    Update order status. If cancelled, stock is automatically released.
    Status flow: pending → confirmed → preparing → ready → delivered
    """
    try:
        order = order_service.update_order_status(db, order_id, data.status)
        return _order_to_out(order)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
