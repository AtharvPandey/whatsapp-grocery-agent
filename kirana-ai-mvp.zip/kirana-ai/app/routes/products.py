"""
routes/products.py
-------------------
REST API for inventory management.
Used by the owner dashboard (web UI) and optionally a mobile app later.
"""

from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app.database import get_db
from app.schemas import ProductCreate, ProductUpdate, ProductOut, StockAdjust
from app.services import inventory_service
from app.services.inventory_service import ProductNotFoundError, InsufficientStockError

router = APIRouter(prefix="/api/products", tags=["Inventory"])


def _to_out(product) -> ProductOut:
    """Helper: converts ORM Product → ProductOut schema."""
    d = {c.name: getattr(product, c.name) for c in product.__table__.columns}
    d["is_low_stock"] = product.is_low_stock()
    return ProductOut(**d)


@router.get("/", response_model=List[ProductOut])
def list_products(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
):
    """List all active products. Supports pagination via skip/limit."""
    products = inventory_service.get_all_products(db, skip=skip, limit=limit)
    return [_to_out(p) for p in products]


@router.get("/search", response_model=List[ProductOut])
def search_products(
    q: str = Query(..., min_length=1, description="Product name search term"),
    db: Session = Depends(get_db),
):
    """Fuzzy search products by name. Used by the AI matcher and owner UI."""
    products = inventory_service.search_products(db, q)
    return [_to_out(p) for p in products]


@router.get("/low-stock", response_model=List[ProductOut])
def low_stock_alerts(db: Session = Depends(get_db)):
    """Return products at or below their low-stock threshold."""
    products = inventory_service.get_low_stock_products(db)
    return [_to_out(p) for p in products]


@router.get("/{product_id}", response_model=ProductOut)
def get_product(product_id: int, db: Session = Depends(get_db)):
    try:
        p = inventory_service.get_product(db, product_id)
        return _to_out(p)
    except ProductNotFoundError:
        raise HTTPException(status_code=404, detail="Product not found")


@router.post("/", response_model=ProductOut, status_code=201)
def create_product(data: ProductCreate, db: Session = Depends(get_db)):
    """Add a new product to inventory."""
    p = inventory_service.create_product(db, data)
    return _to_out(p)


@router.patch("/{product_id}", response_model=ProductOut)
def update_product(product_id: int, data: ProductUpdate, db: Session = Depends(get_db)):
    """Partial update — only send fields you want to change."""
    try:
        p = inventory_service.update_product(db, product_id, data)
        return _to_out(p)
    except ProductNotFoundError:
        raise HTTPException(status_code=404, detail="Product not found")


@router.delete("/{product_id}")
def delete_product(product_id: int, db: Session = Depends(get_db)):
    """Soft-delete a product (keeps historical order data)."""
    try:
        inventory_service.delete_product(db, product_id)
        return {"message": "Product deleted successfully"}
    except ProductNotFoundError:
        raise HTTPException(status_code=404, detail="Product not found")


@router.post("/{product_id}/adjust-stock", response_model=ProductOut)
def adjust_stock(product_id: int, data: StockAdjust, db: Session = Depends(get_db)):
    """
    Manually adjust stock quantity.
    Send positive quantity to add stock (new delivery), negative to remove (damage/loss).
    """
    try:
        p = inventory_service.adjust_stock(db, product_id, data)
        return _to_out(p)
    except ProductNotFoundError:
        raise HTTPException(status_code=404, detail="Product not found")
    except InsufficientStockError as e:
        raise HTTPException(status_code=409, detail=str(e))
