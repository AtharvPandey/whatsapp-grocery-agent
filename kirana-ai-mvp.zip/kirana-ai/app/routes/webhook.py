"""
routes/webhook.py
------------------
Twilio sends a POST request here every time a customer messages the
WhatsApp number. We parse the order, create it in DB, and reply.

Security:
  In production, uncomment the Twilio signature verification block.
  For sandbox testing, the check is relaxed.
"""

from fastapi import APIRouter, Depends, Request, Form, HTTPException
from fastapi.responses import PlainTextResponse
from sqlalchemy.orm import Session
from loguru import logger

from app.database import get_db
from app.whatsapp.handler import handle_inbound_message, verify_twilio_signature
from app.config import settings

router = APIRouter(prefix="/webhook", tags=["WhatsApp Webhook"])


@router.post("/whatsapp", response_class=PlainTextResponse)
async def whatsapp_webhook(
    request: Request,
    From: str = Form(...),
    Body: str = Form(...),
    db: Session = Depends(get_db),
):
    """
    Twilio WhatsApp inbound webhook.

    Twilio sends form-encoded POST with at minimum:
      From: whatsapp:+91XXXXXXXXXX
      Body: the customer's message text
    """
    # ── Signature verification (enable in production) ──────────────────────
    # signature = request.headers.get("X-Twilio-Signature", "")
    # url = str(request.url)
    # form_data = dict(await request.form())
    # if not verify_twilio_signature(url, form_data, signature):
    #     raise HTTPException(status_code=403, detail="Invalid Twilio signature")

    # Normalize phone number (remove "whatsapp:" prefix)
    from_phone = From.replace("whatsapp:", "").strip()

    logger.info(f"Webhook: {from_phone} → {Body[:80]}")

    try:
        reply = handle_inbound_message(db, from_phone, Body)
    except Exception as e:
        logger.error(f"Webhook handler crashed: {e}")
        reply = (
            "Maafi chahte hain, kuch gadbad ho gayi. 🙏\n"
            "Thodi der baad try karein ya seedha call karein: "
            f"{settings.STORE_PHONE}"
        )

    # Twilio expects TwiML XML response OR plain text with TwiML
    # For simplicity we return TwiML with the reply message
    twiml = f"""<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Message>{reply}</Message>
</Response>"""

    return PlainTextResponse(content=twiml, media_type="application/xml")


@router.get("/whatsapp")
async def webhook_health():
    """Simple health check for the webhook endpoint."""
    return {"status": "ok", "message": "WhatsApp webhook is live"}
