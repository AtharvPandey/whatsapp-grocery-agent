"""
schemas/__init__.py
-------------------
Pydantic v2 schemas for API validation and serialisation.
Separating schemas from ORM models keeps the API contract stable
even when the DB schema evolves internally.
"""

from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, Field, field_validator
from app.models import OrderStatus, ProductCategory


# ════════════════════════════════════════════════════════════════
# PRODUCT SCHEMAS
# ════════════════════════════════════════════════════════════════

class ProductBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    name_hindi: Optional[str] = None
    category: ProductCategory = ProductCategory.OTHER
    stock_quantity: float = Field(..., ge=0)
    unit: str = Field(default="piece", max_length=20)
    price: float = Field(..., gt=0)
    low_stock_threshold: float = Field(default=10.0, ge=0)


class ProductCreate(ProductBase):
    pass


class ProductUpdate(BaseModel):
    """All fields optional — only send what you want to change."""
    name: Optional[str] = None
    name_hindi: Optional[str] = None
    category: Optional[ProductCategory] = None
    stock_quantity: Optional[float] = Field(None, ge=0)
    unit: Optional[str] = None
    price: Optional[float] = Field(None, gt=0)
    low_stock_threshold: Optional[float] = None
    is_active: Optional[int] = None


class ProductOut(ProductBase):
    id: int
    is_active: int
    is_low_stock: bool
    created_at: datetime

    model_config = {"from_attributes": True}

    @classmethod
    def from_orm_with_flags(cls, product):
        data = {
            **product.__dict__,
            "is_low_stock": product.is_low_stock(),
        }
        return cls(**data)


class StockAdjust(BaseModel):
    """Used by owner to manually adjust stock (receiving new goods)."""
    quantity: float = Field(..., description="Positive to add, negative to remove")
    reason: Optional[str] = None


# ════════════════════════════════════════════════════════════════
# CUSTOMER SCHEMAS
# ════════════════════════════════════════════════════════════════

class CustomerBase(BaseModel):
    name: Optional[str] = None
    phone: str = Field(..., min_length=10, max_length=20)
    address: Optional[str] = None


class CustomerCreate(CustomerBase):
    pass


class CustomerOut(CustomerBase):
    id: int
    created_at: datetime
    model_config = {"from_attributes": True}


# ════════════════════════════════════════════════════════════════
# ORDER SCHEMAS
# ════════════════════════════════════════════════════════════════

class OrderItemIn(BaseModel):
    product_id: int
    quantity: float = Field(..., gt=0)


class OrderCreate(BaseModel):
    customer_phone: str
    items: List[OrderItemIn] = Field(..., min_length=1)
    notes: Optional[str] = None


class OrderItemOut(BaseModel):
    id: int
    product_id: int
    product_name: str
    quantity: float
    price: float
    subtotal: float
    unit: str

    model_config = {"from_attributes": True}


class OrderOut(BaseModel):
    id: int
    customer_id: int
    customer_phone: str
    total_amount: float
    status: OrderStatus
    notes: Optional[str]
    created_at: datetime
    items: List[OrderItemOut] = []

    model_config = {"from_attributes": True}


class OrderStatusUpdate(BaseModel):
    status: OrderStatus


# ════════════════════════════════════════════════════════════════
# AI PARSER SCHEMAS
# ════════════════════════════════════════════════════════════════

class ParsedItem(BaseModel):
    product_name: str
    quantity: float = 1.0
    unit: Optional[str] = None


class ParsedOrder(BaseModel):
    items: List[ParsedItem]
    raw_message: str


# ════════════════════════════════════════════════════════════════
# DASHBOARD / SUMMARY SCHEMAS
# ════════════════════════════════════════════════════════════════

class DailySummary(BaseModel):
    date: str
    total_orders: int
    total_revenue: float
    pending_orders: int
    low_stock_products: List[str]
