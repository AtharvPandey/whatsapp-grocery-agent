"""
services/inventory_service.py
------------------------------
All inventory business logic lives here — routes just call these functions.

Key design decisions:
- All stock deductions happen inside a DB transaction so you never get
  partial updates (some items deducted, some not).
- We raise explicit exceptions that the route layer can convert to
  HTTP 400/409 responses — clean separation of concerns.
- `reserve_stock` is the critical path: it checks AND deducts atomically
  so concurrent WhatsApp orders can't both "see" the same last unit.
"""

from typing import List, Tuple
from sqlalchemy.orm import Session
from sqlalchemy import func, and_
from loguru import logger

from app.models import Product, OrderItem, Order, OrderStatus
from app.schemas import ProductCreate, ProductUpdate, StockAdjust


class InsufficientStockError(Exception):
    """Raised when an order requests more than available stock."""
    def __init__(self, product_name: str, requested: float, available: float):
        self.product_name = product_name
        self.requested = requested
        self.available = available
        super().__init__(f"{product_name}: need {requested}, only {available} left")


class ProductNotFoundError(Exception):
    pass


# ── CRUD ──────────────────────────────────────────────────────────────────────

def get_product(db: Session, product_id: int) -> Product:
    p = db.query(Product).filter(Product.id == product_id, Product.is_active == 1).first()
    if not p:
        raise ProductNotFoundError(f"Product {product_id} not found")
    return p


def get_all_products(db: Session, skip: int = 0, limit: int = 100) -> List[Product]:
    return (db.query(Product)
              .filter(Product.is_active == 1)
              .offset(skip).limit(limit).all())


def search_products(db: Session, query: str) -> List[Product]:
    """Fuzzy search by name for AI matcher and owner UI."""
    pattern = f"%{query.lower()}%"
    return (db.query(Product)
              .filter(
                  Product.is_active == 1,
                  func.lower(Product.name).like(pattern)
              ).all())


def create_product(db: Session, data: ProductCreate) -> Product:
    product = Product(**data.model_dump())
    db.add(product)
    db.commit()
    db.refresh(product)
    logger.info(f"Created product: {product.name}")
    return product


def update_product(db: Session, product_id: int, data: ProductUpdate) -> Product:
    product = get_product(db, product_id)
    update_data = data.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(product, field, value)
    db.commit()
    db.refresh(product)
    logger.info(f"Updated product {product_id}: {update_data}")
    return product


def delete_product(db: Session, product_id: int) -> bool:
    """Soft delete — keeps historical order data intact."""
    product = get_product(db, product_id)
    product.is_active = 0
    db.commit()
    logger.info(f"Soft-deleted product {product_id}")
    return True


def adjust_stock(db: Session, product_id: int, data: StockAdjust) -> Product:
    """Manual stock adjustment — for receiving new goods or corrections."""
    product = get_product(db, product_id)
    new_qty = product.stock_quantity + data.quantity
    if new_qty < 0:
        raise InsufficientStockError(product.name, abs(data.quantity), product.stock_quantity)
    product.stock_quantity = new_qty
    db.commit()
    db.refresh(product)
    logger.info(f"Stock adjusted: {product.name} by {data.quantity:+} → {new_qty}")
    return product


# ── Stock reservation (transactional) ─────────────────────────────────────────

def reserve_stock(db: Session, items: List[Tuple[Product, float]]) -> None:
    """
    Atomically deduct stock for a list of (product, quantity) pairs.
    Raises InsufficientStockError if ANY item can't be fulfilled.
    Call this BEFORE committing the order row.
    """
    # Validate all first — fail early before touching any stock
    for product, qty in items:
        if product.stock_quantity < qty:
            raise InsufficientStockError(product.name, qty, product.stock_quantity)

    # All checks passed — now deduct
    for product, qty in items:
        product.stock_quantity -= qty
        logger.debug(f"Reserved {qty} of {product.name} → {product.stock_quantity} left")


def release_stock(db: Session, order: Order) -> None:
    """
    Restore stock when an order is CANCELLED.
    Called by the order service when status changes to 'cancelled'.
    """
    for item in order.items:
        item.product.stock_quantity += item.quantity
        logger.info(f"Released {item.quantity} of {item.product.name} back to stock")
    db.commit()


# ── Low stock alerts ───────────────────────────────────────────────────────────

def get_low_stock_products(db: Session) -> List[Product]:
    """Returns all active products at or below their individual threshold."""
    return (db.query(Product)
              .filter(
                  Product.is_active == 1,
                  Product.stock_quantity <= Product.low_stock_threshold
              ).all())
