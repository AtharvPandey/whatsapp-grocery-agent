"""
services/order_service.py
--------------------------
Order lifecycle management.

Flow:
  create_order_from_whatsapp()
    → resolve customer (create if new)
    → look up products
    → reserve stock (transactional)
    → persist order + items
    → return order for confirmation message
"""

from datetime import datetime, date
from typing import List, Optional
from sqlalchemy.orm import Session
from sqlalchemy import func
from loguru import logger

from app.models import Order, OrderItem, OrderStatus, Customer, Product
from app.schemas import OrderCreate, OrderItemIn, DailySummary
from app.services import inventory_service
from app.services.inventory_service import InsufficientStockError


# ── Customer resolution ────────────────────────────────────────────────────────

def get_or_create_customer(db: Session, phone: str, name: Optional[str] = None) -> Customer:
    """Find existing customer by phone or create a new record."""
    customer = db.query(Customer).filter(Customer.phone == phone).first()
    if not customer:
        customer = Customer(phone=phone, name=name)
        db.add(customer)
        db.flush()   # get ID without committing yet
        logger.info(f"New customer registered: {phone}")
    elif name and not customer.name:
        customer.name = name
    return customer


# ── Order creation ─────────────────────────────────────────────────────────────

def create_order(db: Session, data: OrderCreate) -> Order:
    """
    Create an order from structured data (used by API + WhatsApp flow).
    Raises InsufficientStockError if any item is out of stock.
    The entire operation is wrapped in a single DB transaction.
    """
    customer = get_or_create_customer(db, data.customer_phone)

    # Resolve products and pair with quantities
    product_qty_pairs: List[tuple] = []
    for item_in in data.items:
        product = db.query(Product).filter(
            Product.id == item_in.product_id,
            Product.is_active == 1
        ).first()
        if not product:
            raise ValueError(f"Product {item_in.product_id} not found")
        product_qty_pairs.append((product, item_in.quantity))

    # Reserve stock BEFORE persisting the order (fails atomically if any item short)
    inventory_service.reserve_stock(db, product_qty_pairs)

    # Build order
    order = Order(customer_id=customer.id, notes=data.notes)
    db.add(order)
    db.flush()  # get order.id

    total = 0.0
    for product, qty in product_qty_pairs:
        item = OrderItem(
            order_id=order.id,
            product_id=product.id,
            quantity=qty,
            price=product.price,   # snapshot price at order time
        )
        db.add(item)
        total += qty * product.price

    order.total_amount = round(total, 2)
    db.commit()
    db.refresh(order)
    logger.info(f"Order #{order.id} created for {data.customer_phone}, total ₹{order.total_amount}")
    return order


def create_order_from_parsed_items(
    db: Session,
    customer_phone: str,
    parsed_items: list,         # List[ParsedItem] from AI
    resolved_products: list,    # List[Product] matched from DB
    quantities: List[float],
) -> Order:
    """
    Convenience wrapper called directly by the WhatsApp service after AI parsing.
    `resolved_products` and `quantities` are parallel lists.
    """
    items_in = [
        OrderItemIn(product_id=p.id, quantity=q)
        for p, q in zip(resolved_products, quantities)
    ]
    data = OrderCreate(customer_phone=customer_phone, items=items_in)
    return create_order(db, data)


# ── Order retrieval ────────────────────────────────────────────────────────────

def get_order(db: Session, order_id: int) -> Optional[Order]:
    return db.query(Order).filter(Order.id == order_id).first()


def get_orders(db: Session, skip: int = 0, limit: int = 50,
               status: Optional[OrderStatus] = None) -> List[Order]:
    q = db.query(Order)
    if status:
        q = q.filter(Order.status == status)
    return q.order_by(Order.created_at.desc()).offset(skip).limit(limit).all()


def get_customer_orders(db: Session, phone: str) -> List[Order]:
    customer = db.query(Customer).filter(Customer.phone == phone).first()
    if not customer:
        return []
    return (db.query(Order)
              .filter(Order.customer_id == customer.id)
              .order_by(Order.created_at.desc()).all())


# ── Status management ──────────────────────────────────────────────────────────

def update_order_status(db: Session, order_id: int, new_status: OrderStatus) -> Order:
    order = get_order(db, order_id)
    if not order:
        raise ValueError(f"Order {order_id} not found")

    old_status = order.status

    # If cancelling a confirmed order, release the reserved stock back
    if new_status == OrderStatus.CANCELLED and old_status not in (
        OrderStatus.CANCELLED, OrderStatus.DELIVERED
    ):
        inventory_service.release_stock(db, order)

    order.status = new_status
    db.commit()
    db.refresh(order)
    logger.info(f"Order #{order_id}: {old_status} → {new_status}")
    return order


# ── Daily summary ──────────────────────────────────────────────────────────────

def get_daily_summary(db: Session, for_date: Optional[date] = None) -> DailySummary:
    if not for_date:
        for_date = date.today()

    day_start = datetime.combine(for_date, datetime.min.time())
    day_end   = datetime.combine(for_date, datetime.max.time())

    orders_today = (db.query(Order)
                      .filter(Order.created_at.between(day_start, day_end))
                      .all())

    total_revenue = sum(o.total_amount for o in orders_today
                        if o.status != OrderStatus.CANCELLED)
    pending = sum(1 for o in orders_today if o.status == OrderStatus.PENDING)

    low_stock = inventory_service.get_low_stock_products(db)

    return DailySummary(
        date=str(for_date),
        total_orders=len(orders_today),
        total_revenue=round(total_revenue, 2),
        pending_orders=pending,
        low_stock_products=[p.name for p in low_stock],
    )
