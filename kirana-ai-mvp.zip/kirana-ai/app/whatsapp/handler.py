"""
whatsapp/handler.py
--------------------
WhatsApp conversation engine.

This module contains:
  1. `handle_inbound_message` — orchestrates the full order flow
  2. Message builder functions — compose responses in friendly Hindi-English
  3. Twilio sender — sends replies back to WhatsApp

Architecture note:
  The handler is intentionally stateless. All state lives in the DB.
  When we switch from Twilio to Meta Cloud API, only the `send_whatsapp`
  function needs updating — the rest of the logic stays the same.
"""

import hashlib
import hmac
from typing import Optional
from sqlalchemy.orm import Session
from loguru import logger
from twilio.rest import Client as TwilioClient

from app.config import settings
from app.models import Message, Product
from app.ai.order_parser import (
    parse_order_message,
    match_parsed_items_to_inventory,
    check_availability,
)
from app.services import order_service
from app.services.inventory_service import InsufficientStockError


# ── Twilio client (lazy — only used when actually sending) ─────────────────────
_twilio: Optional[TwilioClient] = None

def _get_twilio():
    global _twilio
    if _twilio is None:
        _twilio = TwilioClient(settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN)
    return _twilio


# ── Main conversation handler ─────────────────────────────────────────────────

def handle_inbound_message(db: Session, from_phone: str, body: str) -> str:
    """
    Process an inbound WhatsApp message and return the reply text.
    Also persists the message log to DB.

    Flow:
      1. Parse order via AI
      2. Match to inventory
      3. Check availability
      4. Create order for available items
      5. Compose reply
    """
    body = body.strip()
    logger.info(f"Inbound from {from_phone}: {body[:80]}")

    # Handle simple greetings
    lower = body.lower()
    if any(w in lower for w in ["hello", "hi", "namaste", "namaskar", "helo"]):
        reply = build_greeting_message()
        _log_message(db, from_phone, body, reply)
        return reply

    # Handle status check
    if any(w in lower for w in ["order status", "mera order", "status"]):
        orders = order_service.get_customer_orders(db, from_phone)
        reply = build_order_status_message(orders)
        _log_message(db, from_phone, body, reply)
        return reply

    # ── Main order parsing flow ─────────────────────────────────────────────
    parsed = parse_order_message(body)

    if not parsed.items:
        reply = (
            "Namaste! 🙏\n"
            "Mujhe aapka order samajh nahi aaya.\n\n"
            "Please kuch aisa likhein:\n"
            "• '2 kg atta aur 1 tel'\n"
            "• '500g sugar, 1 packet namak'\n\n"
            "Hum samajhte hain Hindi aur English dono! 😊"
        )
        _log_message(db, from_phone, body, reply)
        return reply

    matched_products, quantities, unmatched = match_parsed_items_to_inventory(db, parsed)
    available_p, available_q, unavailable = check_availability(matched_products, quantities)

    # Build the reply based on what we can and can't fulfil
    reply_parts = []

    if unmatched:
        items_str = ", ".join(unmatched)
        reply_parts.append(
            f"❌ Yeh items hamare paas nahi hain: *{items_str}*"
        )

    if unavailable:
        for product, requested in unavailable:
            reply_parts.append(
                f"⚠️ *{product.name}* — stock mein sirf "
                f"{product.stock_quantity} {product.unit} bacha hai "
                f"(aapne {requested} manga)."
            )

    if available_p:
        try:
            order = order_service.create_order_from_parsed_items(
                db, from_phone, parsed.items, available_p, available_q
            )
            reply_parts.append(build_order_confirmation(order, available_p, available_q))
        except InsufficientStockError as e:
            reply_parts.append(f"⚠️ Stock problem: {e}")
        except Exception as e:
            logger.error(f"Order creation error: {e}")
            reply_parts.append("Kuch gadbad ho gayi. Please thodi der mein try karein.")
    elif not reply_parts:
        reply_parts.append(
            "😔 Aapke saare items abhi available nahi hain.\n"
            "Hum jaldi restock karenge!"
        )

    reply = "\n\n".join(reply_parts)
    _log_message(db, from_phone, body, reply)
    return reply


# ── Message builders ───────────────────────────────────────────────────────────

def build_greeting_message() -> str:
    return (
        f"🛒 *{settings.STORE_NAME}* mein aapka swagat hai!\n\n"
        "Aap apna grocery order yahan likh sakte hain.\n"
        "Jaise: '2 kg atta, 1 litre tel, ek packet namak'\n\n"
        "Hindi ya English — dono chalega! 😊\n"
        "Order status ke liye likhein: *mera order*"
    )


def build_order_confirmation(order, products: list, quantities: list) -> str:
    lines = [f"✅ *Order Confirm Ho Gaya!* (#{order.id})\n"]
    for product, qty in zip(products, quantities):
        lines.append(f"• {product.name}: {qty} {product.unit} — ₹{qty * product.price:.0f}")
    lines.append(f"\n💰 *Total: ₹{order.total_amount:.0f}*")
    lines.append("\nHum aapka order jaldi bhej denge! 🚀")
    return "\n".join(lines)


def build_order_status_message(orders) -> str:
    if not orders:
        return "Aapka koi order nahi mila. Kuch order karna chahenge? 😊"

    latest = orders[0]
    status_emoji = {
        "pending":   "⏳",
        "confirmed": "✅",
        "preparing": "👨‍🍳",
        "ready":     "📦",
        "delivered": "🎉",
        "cancelled": "❌",
    }
    emoji = status_emoji.get(latest.status.value, "📋")
    return (
        f"*Aapka Latest Order #{latest.id}*\n"
        f"Status: {emoji} {latest.status.value.title()}\n"
        f"Amount: ₹{latest.total_amount:.0f}\n"
        f"Date: {latest.created_at.strftime('%d %b, %I:%M %p')}"
    )


# ── Twilio sender ──────────────────────────────────────────────────────────────

def send_whatsapp(to_phone: str, message: str) -> bool:
    """
    Send a WhatsApp message via Twilio.
    Returns True on success, False on failure.

    To switch to Meta Cloud API, replace this function's internals only.
    Signature stays the same so callers don't change.
    """
    if not settings.TWILIO_ACCOUNT_SID or not settings.TWILIO_AUTH_TOKEN:
        logger.warning("Twilio not configured — message not sent (dev mode)")
        logger.info(f"[MOCK SEND] to {to_phone}: {message[:100]}")
        return False

    try:
        twilio = _get_twilio()
        msg = twilio.messages.create(
            from_=settings.TWILIO_WHATSAPP_NUMBER,
            to=f"whatsapp:{to_phone}",
            body=message,
        )
        logger.info(f"Sent WhatsApp SID={msg.sid} to {to_phone}")
        return True
    except Exception as e:
        logger.error(f"Failed to send WhatsApp to {to_phone}: {e}")
        return False


# ── Webhook signature verification ────────────────────────────────────────────

def verify_twilio_signature(url: str, params: dict, signature: str) -> bool:
    """
    Verify that incoming webhooks are genuinely from Twilio.
    Prevents spoofed requests to the /webhook endpoint.
    """
    from twilio.request_validator import RequestValidator
    validator = RequestValidator(settings.TWILIO_AUTH_TOKEN)
    return validator.validate(url, params, signature)


# ── DB helper ─────────────────────────────────────────────────────────────────

def _log_message(db: Session, phone: str, message: str, response: str):
    """Persist conversation to DB for audit and future analytics."""
    # Ensure customer record exists
    order_service.get_or_create_customer(db, phone)
    db.add(Message(
        customer_phone=phone,
        direction="inbound",
        message=message,
        response=response,
    ))
    db.commit()
